package seleniumpracticeJ;
public interface Vehicle {
public void speed();
public void capacity();
public void milage();
	interface Bike{
		int numberofwheels = 2;
		String outercovering = "No OuterCover";
		public void fuel();
	}
}